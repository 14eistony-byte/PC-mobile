# NEXUS-PC-Pluginformat (Entwurf)

Der Store verwendet in Version 1.1.0 noch eingebaute lokale Module. Diese Beispieldatei dokumentiert ein mögliches Manifest für zukünftige Plugins.

- `id`: eindeutige Plugin-ID
- `name`: sichtbarer Name
- `version`: Plugin-Version
- `description`: kurze Beschreibung
- `entry`: Einstiegspunkt (wird aktuell noch nicht geladen)
- `permissions`: angeforderte Berechtigungen; leer lassen, wenn keine benötigt werden
- `minNexusVersion`: benötigte NEXUS-PC-Version

Fremde Plugins dürfen nicht ungeprüft direkt in der App ausgeführt werden. Vor einer echten Plugin-Installation sind Signaturprüfung, Herkunftsnachweis, Berechtigungsdialoge, Versionsprüfung und eine isolierte Ausführungsumgebung erforderlich.
