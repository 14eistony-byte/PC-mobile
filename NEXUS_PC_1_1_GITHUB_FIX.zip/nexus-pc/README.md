# NEXUS PC 1.1.0

NEXUS PC ist eine Android-App, die einen Windows-11-ähnlichen Desktop simuliert. Sie ist **kein echtes Windows** und führt keine Windows-EXE-Dateien aus.

## Neu in Version 1.1.0

- Echter eingebetteter WebView-Browser mit Zurück, Vorwärts und Neu laden
- Notizen, installierte Store-Apps, Aufgaben und Einstellungen werden auf dem Gerät gespeichert
- Datei-Explorer kann den Android-Dateiauswahldialog öffnen und Dateimetadaten in NEXUS anzeigen
- Fenster können verschoben, minimiert, maximiert und geschlossen werden
- Neue Apps: Uhr, Kalender und Aufgabenliste
- Taschenrechner mit eigener Ausdrucksauswertung statt JavaScript-`eval`
- APK-Build-Profil für eine eigenständige Installation ohne Expo Go

## APK bauen (Expo Go ist nicht erforderlich)

Voraussetzungen: Node.js LTS und ein Expo/EAS-Konto mit Internetzugang.

1. ZIP entpacken und in den Projektordner `nexus-pc` wechseln.
2. Abhängigkeiten installieren:

   ```bash
   npm install
   ```

3. Einmalig bei EAS anmelden:

   ```bash
   npx eas login
   ```

4. APK erstellen:

   ```bash
   npm run build:apk
   ```

5. Nach erfolgreichem Cloud-Build den APK-Link aus der EAS-Ausgabe öffnen und die APK auf dem Android-Handy installieren. Android kann eine Bestätigung für die Installation aus dieser Quelle anzeigen.

Die APK wird durch EAS Build auf den Expo-Buildservern erzeugt. Dieses ZIP selbst ist noch keine APK.

## Projekt lokal starten

```bash
npm install
npx expo start
```

Für die normale APK-Installation wird Expo Go nicht benötigt.

## Enthaltene Apps

- Browser (WebView)
- Datei-Explorer mit Android-Dateiauswahl
- Editor mit automatischer Speicherung
- Taschenrechner
- Einstellungen
- NEXUS Store
- Uhr, Kalender und Aufgabenliste (über den Store installierbar)

## Grenzen und Sicherheit

- NEXUS PC ist eine Desktop-Simulation, kein vollständiges Betriebssystem.
- Windows-EXE-Dateien und beliebige PC-Programme können nicht direkt ausgeführt werden.
- Der Datei-Explorer merkt sich in dieser Version Dateinamen und Metadaten ausgewählter Dateien; er ist noch kein vollständiger Dateimanager.
- Store-Erweiterungen sind lokale App-Module. Beliebiger fremder JavaScript-Code wird nicht heruntergeladen oder ausgeführt.
- Der Browser zeigt Websites an. Anmeldedaten sollten nur auf vertrauenswürdigen Websites eingegeben werden.

## Build-Fehler melden

Wenn `npm run build:apk` fehlschlägt, öffne in EAS den fehlgeschlagenen Build, kopiere den Abschnitt **Build Logs** ab der ersten roten Fehlermeldung oder exportiere die Logs. Sende diesen Text zusammen mit der Ausgabe von `npx expo-doctor`.

## APK direkt in der Cloud bauen (ohne Expo Go und ohne lokalen PC-Build)

Im Repository ist ein GitHub-Actions-Workflow enthalten: `.github/workflows/android-apk.yml`.

1. Lade den Inhalt dieses Projektordners in ein GitHub-Repository hoch.
2. Öffne im Repository den Tab **Actions**.
3. Wähle **Build NEXUS PC APK** und tippe auf **Run workflow**.
4. Warte, bis der Lauf grün abgeschlossen ist.
5. Öffne den abgeschlossenen Lauf und lade unter **Artifacts** `NEXUS-PC-1.1-APK` herunter.
6. Entpacke das Artifact und installiere `app-release.apk` auf Android.

Hinweis: Der Workflow baut die APK auf GitHub-Servern. Dafür brauchst du ein GitHub-Konto und musst den Workflow im Repository starten. Ein erfolgreicher Build ist nicht garantiert; bei Fehlern sind die Build-Logs nötig.
