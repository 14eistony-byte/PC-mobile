import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  SafeAreaView, View, Text, TouchableOpacity, ScrollView, Modal,
  TextInput, StatusBar, Alert, Pressable, useWindowDimensions,
  PanResponder, ActivityIndicator
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as DocumentPicker from 'expo-document-picker';
import { WebView } from 'react-native-webview';

const STORAGE_KEY = '@nexus-pc/state-v1';
const SYSTEM_APP_IDS = ['browser', 'files', 'notes', 'calculator', 'settings', 'store'];

const INITIAL_APPS = [
  { id: 'browser', name: 'Browser', icon: '🌐', description: 'Webseiten direkt im virtuellen PC öffnen.' },
  { id: 'files', name: 'Datei-Explorer', icon: '📁', description: 'Ordner ansehen und Dateien vom Handy auswählen.' },
  { id: 'notes', name: 'Editor', icon: '📝', description: 'Notizen schreiben und automatisch speichern.' },
  { id: 'calculator', name: 'Rechner', icon: '🧮', description: 'Ein einfacher Taschenrechner.' },
  { id: 'settings', name: 'Einstellungen', icon: '⚙️', description: 'Darstellung und Systeminformationen.' },
  { id: 'store', name: 'NEXUS Store', icon: '🛍️', description: 'Weitere lokale Demo-Apps installieren.' }
];

const STORE_APPS = [
  { id: 'clock', name: 'Uhr', icon: '🕒', description: 'Uhrzeit, Datum und Sekundenanzeige.' },
  { id: 'calendar', name: 'Kalender', icon: '📅', description: 'Monatsübersicht mit dem aktuellen Datum.' },
  { id: 'tasks', name: 'Aufgaben', icon: '✅', description: 'Eine kleine Aufgabenliste für deinen Desktop.' },
  { id: 'music', name: 'Musik', icon: '🎵', description: 'Platzhalter für eine spätere Musik-App.' },
  { id: 'paint', name: 'Paint', icon: '🎨', description: 'Platzhalter für eine spätere Zeichen-App.' },
  { id: 'weather', name: 'Wetter', icon: '🌤️', description: 'Platzhalter für eine spätere Wetter-App.' }
];

function AppIcon({ app, onPress, small = false }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.iconButton, small && styles.smallIcon]} activeOpacity={0.75}>
      <Text style={[styles.iconEmoji, small && { fontSize: 22 }]}>{app.icon}</Text>
      <Text numberOfLines={2} style={styles.iconLabel}>{app.name}</Text>
    </TouchableOpacity>
  );
}

function normalizeWebAddress(value) {
  const trimmed = String(value || '').trim();
  if (!trimmed) return null;
  const candidate = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  if (!/^https?:\/\/[^\s/]+(?:\/[^\s]*)?$/i.test(candidate)) return null;
  return candidate;
}

function BrowserPanel({ initialUrl, onSaveUrl, dark, fg, muted }) {
  const webRef = useRef(null);
  const [address, setAddress] = useState(initialUrl || 'https://example.com');
  const [source, setSource] = useState(normalizeWebAddress(initialUrl) || 'https://example.com');
  const [canGoBack, setCanGoBack] = useState(false);
  const [canGoForward, setCanGoForward] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  function openAddress() {
    const next = normalizeWebAddress(address);
    if (!next) {
      Alert.alert('Ungültige Adresse', 'Gib eine Webadresse wie https://example.com ein.');
      return;
    }
    setError('');
    setSource(next);
    setAddress(next);
    onSaveUrl(next);
  }

  return (
    <View style={{ flex: 1, gap: 8 }}>
      <View style={styles.addressRow}>
        <TextInput
          value={address}
          onChangeText={setAddress}
          onSubmitEditing={openAddress}
          autoCapitalize="none"
          autoCorrect={false}
          keyboardType="url"
          returnKeyType="go"
          style={[styles.input, { flex: 1 }]}
          placeholder="https://example.com"
          placeholderTextColor="#8290a5"
        />
        <TouchableOpacity style={styles.primaryButton} onPress={openAddress}><Text style={styles.buttonText}>Los</Text></TouchableOpacity>
      </View>
      <View style={styles.browserControls}>
        <TouchableOpacity style={styles.browserButton} disabled={!canGoBack} onPress={() => webRef.current?.goBack()}><Text style={{ color: fg }}>‹</Text></TouchableOpacity>
        <TouchableOpacity style={styles.browserButton} disabled={!canGoForward} onPress={() => webRef.current?.goForward()}><Text style={{ color: fg }}>›</Text></TouchableOpacity>
        <TouchableOpacity style={styles.browserButton} onPress={() => webRef.current?.reload()}><Text style={{ color: fg }}>↻</Text></TouchableOpacity>
        {loading ? <ActivityIndicator size="small" color="#60a5fa" /> : <Text style={[styles.muted, { flex: 1 }]} numberOfLines={1}>NEXUS Web</Text>}
      </View>
      {error ? <Text style={{ color: '#fca5a5', fontSize: 12 }}>{error}</Text> : null}
      <View style={[styles.webFrame, { backgroundColor: dark ? '#fff' : '#f8fafc' }]}>
        <WebView
          ref={webRef}
          source={{ uri: source }}
          onLoadStart={() => { setLoading(true); setError(''); }}
          onLoadEnd={() => setLoading(false)}
          onNavigationStateChange={(state) => {
            setCanGoBack(state.canGoBack);
            setCanGoForward(state.canGoForward);
            if (state.url && /^https?:\/\//i.test(state.url)) setAddress(state.url);
          }}
          onError={() => { setLoading(false); setError('Diese Seite konnte nicht geladen werden. Prüfe die Internetverbindung oder die Adresse.'); }}
          startInLoadingState
          javaScriptEnabled
          domStorageEnabled
          allowsBackForwardNavigationGestures
          setSupportMultipleWindows={false}
          style={{ flex: 1, backgroundColor: '#fff' }}
        />
      </View>
      <Text style={[styles.muted, { fontSize: 10 }]}>Webseiten können eigene Datenschutz- und Nutzungsregeln haben. Melde dich nur auf vertrauenswürdigen Seiten an.</Text>
    </View>
  );
}

function WindowFrame({ children, app, panel, fg, active, width, height, onFocus, onMinimize, onMaximize, onClose }) {
  const [position, setPosition] = useState({ x: 12, y: 12 });
  const positionRef = useRef(position);
  const startRef = useRef(position);
  useEffect(() => { positionRef.current = position; }, [position]);
  const panResponder = useMemo(() => PanResponder.create({
    onStartShouldSetPanResponder: () => false,
    onMoveShouldSetPanResponder: (_, gesture) => Math.abs(gesture.dx) > 3 || Math.abs(gesture.dy) > 3,
    onPanResponderGrant: () => { startRef.current = positionRef.current; onFocus(); },
    onPanResponderMove: (_, gesture) => {
      const next = { x: Math.max(0, startRef.current.x + gesture.dx), y: Math.max(0, startRef.current.y + gesture.dy) };
      positionRef.current = next;
      setPosition(next);
    }
  }), []);

  return (
    <View style={[styles.window, {
      backgroundColor: panel,
      width,
      height,
      left: position.x,
      top: position.y,
      zIndex: active ? 30 : 20,
      borderColor: active ? '#5b9cff' : '#43536a'
    }]} onTouchStart={onFocus}>
      <View style={styles.windowTitle} {...panResponder.panHandlers}>
        <Text numberOfLines={1} style={{ color: '#f5f7fb', fontWeight: '700', flex: 1 }}>{app.icon}  {app.name}</Text>
        <TouchableOpacity onPress={onMinimize} style={styles.titleAction}><Text style={styles.titleActionText}>—</Text></TouchableOpacity>
        <TouchableOpacity onPress={onMaximize} style={styles.titleAction}><Text style={styles.titleActionText}>□</Text></TouchableOpacity>
        <TouchableOpacity onPress={onClose} style={styles.closeButton}><Text style={{ color: '#fff', fontWeight: '800' }}>×</Text></TouchableOpacity>
      </View>
      <View style={{ padding: 12, flex: 1 }}>{children}</View>
    </View>
  );
}

function evaluateExpression(expression) {
  const source = String(expression).replace(/[×]/g, '*').replace(/[÷]/g, '/').replace(/[−]/g, '-').replace(/\s+/g, '');
  if (!source || !/^[0-9.+*/()\-]+$/.test(source)) throw new Error('Ungültige Zeichen');
  const tokens = source.match(/(?:\d+(?:\.\d*)?|\.\d+)|[()+*/-]/g) || [];
  if (tokens.join('') !== source) throw new Error('Ungültige Eingabe');
  let index = 0;
  function parseFactor() {
    const token = tokens[index++];
    if (token === '+') return parseFactor();
    if (token === '-') return -parseFactor();
    if (token === '(') {
      const value = parseExpression();
      if (tokens[index++] !== ')') throw new Error('Klammer fehlt');
      return value;
    }
    const number = Number(token);
    if (!Number.isFinite(number)) throw new Error('Zahl erwartet');
    return number;
  }
  function parseTerm() {
    let value = parseFactor();
    while (tokens[index] === '*' || tokens[index] === '/') {
      const op = tokens[index++];
      const right = parseFactor();
      if (op === '/' && right === 0) throw new Error('Division durch 0');
      value = op === '*' ? value * right : value / right;
    }
    return value;
  }
  function parseExpression() {
    let value = parseTerm();
    while (tokens[index] === '+' || tokens[index] === '-') {
      const op = tokens[index++];
      const right = parseTerm();
      value = op === '+' ? value + right : value - right;
    }
    return value;
  }
  const result = parseExpression();
  if (index !== tokens.length || !Number.isFinite(result)) throw new Error('Rechnung ungültig');
  return Number(result.toPrecision(10)).toString();
}

export default function App() {
  const { width, height } = useWindowDimensions();
  const [installed, setInstalled] = useState(INITIAL_APPS);
  const [openWindows, setOpenWindows] = useState([]);
  const [active, setActive] = useState(null);
  const [startOpen, setStartOpen] = useState(false);
  const [quickOpen, setQuickOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [note, setNote] = useState('');
  const [browserUrl, setBrowserUrl] = useState('https://example.com');
  const [dark, setDark] = useState(true);
  const [calc, setCalc] = useState('');
  const [filePath, setFilePath] = useState('Dieser PC');
  const [importedFiles, setImportedFiles] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [time, setTime] = useState(new Date());
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (raw && mounted) {
          const saved = JSON.parse(raw);
          if (Array.isArray(saved.installed)) setInstalled([...INITIAL_APPS, ...saved.installed.filter(a => !SYSTEM_APP_IDS.includes(a.id))]);
          if (typeof saved.note === 'string') setNote(saved.note);
          if (typeof saved.browserUrl === 'string') setBrowserUrl(saved.browserUrl);
          if (typeof saved.dark === 'boolean') setDark(saved.dark);
          if (Array.isArray(saved.importedFiles)) setImportedFiles(saved.importedFiles);
          if (Array.isArray(saved.tasks)) setTasks(saved.tasks);
        }
      } catch (error) {
        console.warn('NEXUS PC: gespeicherte Daten konnten nicht geladen werden.', error);
      } finally {
        if (mounted) setHydrated(true);
      }
    })();
    return () => { mounted = false; };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const save = {
      installed: installed.filter(a => !SYSTEM_APP_IDS.includes(a.id)),
      note, browserUrl, dark, importedFiles, tasks
    };
    AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(save)).catch(error => console.warn('NEXUS PC: Speichern fehlgeschlagen.', error));
  }, [hydrated, installed, note, browserUrl, dark, importedFiles, tasks]);

  const clock = time.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
  const seconds = time.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const date = time.toLocaleDateString('de-DE', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  const bg = dark ? '#101827' : '#dce8f7';
  const panel = dark ? '#182438' : '#f7faff';
  const fg = dark ? '#f5f7fb' : '#172033';
  const muted = dark ? '#aab7ca' : '#52627a';
  const winWidth = Math.max(260, Math.min(width - 24, 720));
  const winHeight = Math.max(230, Math.min(height - 100, 610));

  function launch(app) {
    setStartOpen(false);
    setQuickOpen(false);
    setOpenWindows(prev => {
      const existing = prev.some(w => w.id === app.id);
      if (existing) return prev.map(w => w.id === app.id ? { ...w, minimized: false } : w);
      return [...prev, { ...app, minimized: false, maximized: false }];
    });
    setActive(app.id);
  }

  function focusWindow(id) {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, minimized: false } : w));
    setActive(id);
  }

  function closeWindow(id) {
    setOpenWindows(prev => prev.filter(w => w.id !== id));
    if (active === id) {
      const remaining = openWindows.filter(w => w.id !== id && !w.minimized);
      setActive(remaining.length ? remaining[remaining.length - 1].id : null);
    }
  }

  function minimizeWindow(id) {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, minimized: true } : w));
    if (active === id) {
      const next = openWindows.filter(w => w.id !== id && !w.minimized).slice(-1)[0];
      setActive(next ? next.id : null);
    }
  }

  function toggleMaximize(id) {
    setOpenWindows(prev => prev.map(w => w.id === id ? { ...w, maximized: !w.maximized } : w));
  }

  function install(app) {
    if (installed.some(a => a.id === app.id)) {
      Alert.alert('Schon installiert', `${app.name} ist bereits installiert.`);
      return;
    }
    setInstalled(prev => [...prev, app]);
    Alert.alert('Installiert', `${app.name} wurde zu NEXUS PC hinzugefügt.`);
  }

  function uninstall(app) {
    if (SYSTEM_APP_IDS.includes(app.id)) {
      Alert.alert('System-App', 'Diese App gehört zum Grundsystem und kann nicht entfernt werden.');
      return;
    }
    Alert.alert('App entfernen', `${app.name} deinstallieren?`, [
      { text: 'Abbrechen', style: 'cancel' },
      { text: 'Entfernen', style: 'destructive', onPress: () => {
        setInstalled(prev => prev.filter(a => a.id !== app.id));
        closeWindow(app.id);
      } }
    ]);
  }

  async function importFiles() {
    try {
      const result = await DocumentPicker.getDocumentAsync({ multiple: true, copyToCacheDirectory: true });
      if (result.canceled) return;
      const entries = (result.assets || []).map(file => ({
        name: file.name || 'Datei',
        size: file.size || 0,
        mimeType: file.mimeType || 'Unbekannter Dateityp',
        uri: file.uri,
        addedAt: new Date().toISOString()
      }));
      setImportedFiles(prev => [...entries, ...prev].slice(0, 50));
      Alert.alert('Import abgeschlossen', `${entries.length} Datei(en) wurden zur NEXUS-Dateiliste hinzugefügt.`);
    } catch (error) {
      Alert.alert('Import fehlgeschlagen', 'Die Datei konnte nicht ausgewählt werden.');
    }
  }

  function addTask() {
    const title = newTask.trim();
    if (!title) return;
    setTasks(prev => [{ id: `${Date.now()}-${Math.random()}`, title, done: false }, ...prev]);
    setNewTask('');
  }

  function renderApp(app) {
    let body;
    if (app.id === 'browser') {
      body = <BrowserPanel initialUrl={browserUrl} onSaveUrl={setBrowserUrl} dark={dark} fg={fg} muted={muted} />;
    } else if (app.id === 'files') {
      const folders = ['Desktop', 'Dokumente', 'Downloads', 'Bilder', 'Musik'];
      body = (
        <View style={{ flex: 1 }}>
          <Text style={[styles.muted, { marginBottom: 8 }]}>Speicherorte  /  {filePath}</Text>
          <View style={styles.fileToolbar}>
            <TouchableOpacity style={styles.primaryButton} onPress={importFiles}><Text style={styles.buttonText}>＋ Dateien vom Handy auswählen</Text></TouchableOpacity>
          </View>
          <ScrollView>
            {folders.map(folder => (
              <TouchableOpacity key={folder} onPress={() => setFilePath(folder)} style={styles.fileRow}>
                <Text style={{ fontSize: 22 }}>📁</Text>
                <Text style={[styles.fileName, { color: fg }]}>{folder}</Text>
                <Text style={{ color: muted }}>›</Text>
              </TouchableOpacity>
            ))}
            <Text style={[styles.sectionTitle, { color: fg, marginTop: 15, marginBottom: 5 }]}>Importierte Dateien ({importedFiles.length})</Text>
            {importedFiles.length === 0 ? <Text style={styles.muted}>Noch keine Dateien importiert.</Text> : importedFiles.map((file, index) => (
              <TouchableOpacity key={`${file.name}-${index}`} onPress={() => Alert.alert(file.name, `${file.mimeType}\n${file.size ? `${Math.round(file.size / 1024)} KB` : 'Größe nicht verfügbar'}\n\nDie Datei ist ausgewählt. Das Öffnen mit einer passenden App folgt in einer späteren Version.`)} style={styles.fileRow}>
                <Text style={{ fontSize: 21 }}>📄</Text>
                <View style={{ flex: 1 }}><Text numberOfLines={1} style={[styles.fileName, { color: fg }]}>{file.name}</Text><Text style={[styles.muted, { fontSize: 10 }]}>{file.mimeType}</Text></View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <Text style={[styles.muted, { marginTop: 6, fontSize: 10 }]}>Der Android-Dateiauswahldialog wird verwendet. Die Liste in NEXUS PC speichert Dateinamen und Metadaten.</Text>
        </View>
      );
    } else if (app.id === 'notes') {
      body = <View style={{ flex: 1, gap: 8 }}>
        <Text style={[styles.muted, { fontSize: 11 }]}>Deine Notiz wird automatisch auf dem Gerät gespeichert.</Text>
        <TextInput value={note} onChangeText={setNote} multiline placeholder="Schreibe deine Notizen ..." placeholderTextColor="#8290a5" style={[styles.input, { flex: 1, textAlignVertical: 'top', padding: 14 }]} />
        <Text style={styles.muted}>{note.length} Zeichen</Text>
      </View>;
    } else if (app.id === 'calculator') {
      body = <View style={{ flex: 1, justifyContent: 'center' }}>
        <Text numberOfLines={1} style={[styles.calcDisplay, { color: fg }]}>{calc || '0'}</Text>
        <View style={styles.calcGrid}>{['7', '8', '9', '÷', '4', '5', '6', '×', '1', '2', '3', '−', '(', '0', ')', '+', 'C', '.', '=', '−'].map((key, index) => (
          <TouchableOpacity key={`${key}-${index}`} style={styles.calcKey} onPress={() => {
            if (key === 'C') setCalc('');
            else if (key === '=') {
              try { setCalc(evaluateExpression(calc)); }
              catch (error) { Alert.alert('Rechenfehler', error.message || 'Bitte prüfe die Rechnung.'); }
            } else setCalc(value => value + key);
          }}><Text style={{ color: fg, fontSize: 18, fontWeight: '600' }}>{key}</Text></TouchableOpacity>
        ))}</View>
      </View>;
    } else if (app.id === 'settings') {
      body = <ScrollView contentContainerStyle={{ gap: 12 }}>
        <Text style={[styles.sectionTitle, { color: fg }]}>Personalisierung</Text>
        <TouchableOpacity style={styles.settingRow} onPress={() => setDark(value => !value)}><Text style={{ color: fg }}>Dunkles Design</Text><Text style={{ color: '#60a5fa' }}>{dark ? 'Ein' : 'Aus'} · Ändern</Text></TouchableOpacity>
        <Text style={[styles.sectionTitle, { color: fg, marginTop: 10 }]}>System</Text>
        <View style={styles.infoRow}><Text style={{ color: muted }}>Systemname</Text><Text style={{ color: fg }}>NEXUS PC</Text></View>
        <View style={styles.infoRow}><Text style={{ color: muted }}>Version</Text><Text style={{ color: fg }}>1.1.0</Text></View>
        <View style={styles.infoRow}><Text style={{ color: muted }}>Installierte Apps</Text><Text style={{ color: fg }}>{installed.length}</Text></View>
        <View style={styles.infoRow}><Text style={{ color: muted }}>Gespeicherte Aufgaben</Text><Text style={{ color: fg }}>{tasks.length}</Text></View>
        <Text style={[styles.muted, { marginTop: 8 }]}>NEXUS PC ist eine PC-Simulation und kein echtes Windows-Betriebssystem. Windows-EXE-Dateien werden nicht direkt ausgeführt.</Text>
      </ScrollView>;
    } else if (app.id === 'store') {
      body = <ScrollView>
        <Text style={[styles.sectionTitle, { color: fg, marginBottom: 10 }]}>Entdecke Apps</Text>
        {STORE_APPS.map(item => {
          const alreadyInstalled = installed.some(entry => entry.id === item.id);
          return <View key={item.id} style={styles.storeRow}>
            <Text style={{ fontSize: 27 }}>{item.icon}</Text>
            <View style={{ flex: 1 }}><Text style={{ color: fg, fontWeight: '700' }}>{item.name}</Text><Text style={{ color: muted, fontSize: 11 }}>{item.description}</Text></View>
            <TouchableOpacity disabled={alreadyInstalled} style={[styles.primaryButton, alreadyInstalled && { backgroundColor: '#52647b' }]} onPress={() => install(item)}><Text style={styles.buttonText}>{alreadyInstalled ? 'Installiert' : 'Installieren'}</Text></TouchableOpacity>
          </View>;
        })}
        <Text style={[styles.muted, { marginTop: 12 }]}>Diese Store-Apps sind lokale Module. Externe Plugins benötigen später ein geprüftes Manifest, klare Berechtigungen und eine isolierte Ausführung.</Text>
      </ScrollView>;
    } else if (app.id === 'clock') {
      body = <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 }}>
        <Text style={{ color: fg, fontSize: 44, fontWeight: '800', fontVariant: ['tabular-nums'] }}>{seconds}</Text>
        <Text style={{ color: muted, fontSize: 17 }}>{date}</Text>
        <Text style={[styles.muted, { marginTop: 8 }]}>NEXUS Uhr</Text>
      </View>;
    } else if (app.id === 'calendar') {
      const year = time.getFullYear();
      const month = time.getMonth();
      const firstWeekday = (new Date(year, month, 1).getDay() + 6) % 7;
      const daysInMonth = new Date(year, month + 1, 0).getDate();
      const cells = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
      while (cells.length % 7) cells.push(null);
      body = <View style={{ flex: 1 }}>
        <Text style={[styles.sectionTitle, { color: fg, marginBottom: 12 }]}>{time.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}</Text>
        <View style={styles.calendarGrid}>{['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(day => <Text key={day} style={[styles.calendarCell, { color: muted, fontWeight: '700' }]}>{day}</Text>)}</View>
        <View style={styles.calendarGrid}>{cells.map((day, index) => <View key={index} style={[styles.calendarCell, day === time.getDate() && styles.todayCell]}><Text style={{ color: day === time.getDate() ? '#fff' : fg, fontWeight: day === time.getDate() ? '800' : '500' }}>{day || ''}</Text></View>)}</View>
        <Text style={[styles.muted, { marginTop: 14 }]}>Heute: {date}</Text>
      </View>;
    } else if (app.id === 'tasks') {
      body = <View style={{ flex: 1, gap: 10 }}>
        <View style={styles.addressRow}><TextInput value={newTask} onChangeText={setNewTask} onSubmitEditing={addTask} returnKeyType="done" placeholder="Neue Aufgabe ..." placeholderTextColor="#8290a5" style={[styles.input, { flex: 1 }]} /><TouchableOpacity style={styles.primaryButton} onPress={addTask}><Text style={styles.buttonText}>＋</Text></TouchableOpacity></View>
        <ScrollView>
          {tasks.length === 0 ? <Text style={styles.muted}>Noch keine Aufgaben. Füge oben deine erste Aufgabe hinzu.</Text> : tasks.map(task => <View key={task.id} style={styles.taskRow}>
            <TouchableOpacity onPress={() => setTasks(prev => prev.map(item => item.id === task.id ? { ...item, done: !item.done } : item))} style={[styles.taskCheck, task.done && styles.taskChecked]}><Text style={{ color: '#fff' }}>{task.done ? '✓' : ''}</Text></TouchableOpacity>
            <Text style={[styles.taskTitle, { color: fg, textDecorationLine: task.done ? 'line-through' : 'none', opacity: task.done ? 0.55 : 1 }]}>{task.title}</Text>
            <TouchableOpacity onPress={() => setTasks(prev => prev.filter(item => item.id !== task.id))}><Text style={{ color: '#f87171', fontSize: 18 }}>×</Text></TouchableOpacity>
          </View>)}
        </ScrollView>
        <Text style={styles.muted}>{tasks.filter(task => task.done).length} von {tasks.length} erledigt</Text>
      </View>;
    } else {
      body = <View style={{ alignItems: 'center', justifyContent: 'center', flex: 1 }}>
        <Text style={{ fontSize: 44 }}>{app.icon}</Text>
        <Text style={{ color: fg, fontSize: 20, fontWeight: '700', marginTop: 8 }}>{app.name}</Text>
        <Text style={{ color: muted, marginTop: 8, textAlign: 'center' }}>{app.description || 'Weitere Funktionen folgen als App-Modul.'}</Text>
        <TouchableOpacity style={[styles.primaryButton, { marginTop: 16 }]} onPress={() => uninstall(app)}><Text style={styles.buttonText}>Deinstallieren</Text></TouchableOpacity>
      </View>;
    }

    const window = openWindows.find(item => item.id === app.id);
    const maximized = !!window?.maximized;
    return (
      <WindowFrame
        key={app.id}
        app={app}
        panel={panel}
        fg={fg}
        active={active === app.id}
        width={maximized ? width - 16 : winWidth}
        height={maximized ? height - 78 : winHeight}
        onFocus={() => focusWindow(app.id)}
        onMinimize={() => minimizeWindow(app.id)}
        onMaximize={() => toggleMaximize(app.id)}
        onClose={() => closeWindow(app.id)}
      >{body}</WindowFrame>
    );
  }

  const filteredApps = installed.filter(app => app.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <SafeAreaView style={[styles.safe, { backgroundColor: bg }]}>
      <StatusBar hidden />
      <Pressable style={styles.desktop} onPress={() => { if (startOpen) setStartOpen(false); }}>
        <View style={styles.desktopIcons}>
          {installed.slice(0, 10).map(app => <AppIcon key={app.id} app={app} onPress={() => launch(app)} />)}
        </View>
        {openWindows.filter(window => !window.minimized).map(window => renderApp(window))}
        <View style={styles.taskbar}>
          <TouchableOpacity style={styles.startButton} onPress={() => setStartOpen(value => !value)}><Text style={{ fontSize: 20 }}>🪟</Text></TouchableOpacity>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ alignItems: 'center', gap: 6, flexGrow: 1 }}>
            {openWindows.map(window => <TouchableOpacity key={window.id} onPress={() => focusWindow(window.id)} style={[styles.taskItem, active === window.id && styles.taskActive, window.minimized && { opacity: 0.6 }]}><Text>{window.icon}</Text><Text numberOfLines={1} style={{ color: fg, fontSize: 11, maxWidth: 78 }}>{window.name}</Text></TouchableOpacity>)}
          </ScrollView>
          <TouchableOpacity style={styles.tray} onPress={() => setQuickOpen(value => !value)}><Text style={{ color: fg, fontSize: 10 }}>📶 🔊 🔋</Text><Text style={{ color: fg, fontSize: 11 }}>{clock}</Text></TouchableOpacity>
        </View>
      </Pressable>

      <Modal visible={startOpen} transparent animationType="fade" onRequestClose={() => setStartOpen(false)}>
        <Pressable style={styles.overlay} onPress={() => setStartOpen(false)}>
          <Pressable style={[styles.startPanel, { backgroundColor: panel }]} onPress={() => {}}>
            <Text style={[styles.panelHeading, { color: fg }]}>Start</Text>
            <TextInput value={search} onChangeText={setSearch} placeholder="Apps suchen ..." placeholderTextColor="#8290a5" style={styles.input} />
            <ScrollView contentContainerStyle={styles.startGrid}>{filteredApps.map(app => <AppIcon key={app.id} app={app} onPress={() => launch(app)} small />)}</ScrollView>
            <Text style={[styles.muted, { marginTop: 10 }]}>NEXUS PC · Version 1.1.0</Text>
          </Pressable>
        </Pressable>
      </Modal>

      <Modal visible={quickOpen} transparent animationType="fade" onRequestClose={() => setQuickOpen(false)}>
        <Pressable style={styles.overlay} onPress={() => setQuickOpen(false)}>
          <View style={[styles.quickPanel, { backgroundColor: panel }]}>
            <Text style={[styles.panelHeading, { color: fg }]}>Schnelleinstellungen</Text>
            <TouchableOpacity style={styles.settingRow} onPress={() => setDark(value => !value)}><Text style={{ color: fg }}>🌙 Dunkles Design</Text><Text style={{ color: '#60a5fa' }}>{dark ? 'Ein' : 'Aus'}</Text></TouchableOpacity>
            <Text style={[styles.muted, { marginTop: 12 }]}>{date} · {clock}</Text>
            <Text style={[styles.muted, { marginTop: 8 }]}>Speicherstatus: {hydrated ? 'Bereit' : 'Wird geladen …'}</Text>
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = {
  safe: { flex: 1 },
  desktop: { flex: 1, backgroundColor: '#102c50' },
  desktopIcons: { flexDirection: 'row', flexWrap: 'wrap', alignContent: 'flex-start', padding: 8, gap: 5 },
  iconButton: { width: 76, minHeight: 76, alignItems: 'center', justifyContent: 'center', padding: 4, borderRadius: 10 },
  smallIcon: { width: 78, height: 78 },
  iconEmoji: { fontSize: 28, marginBottom: 4 },
  iconLabel: { color: '#fff', fontSize: 10, textAlign: 'center', textShadowColor: '#000', textShadowRadius: 3 },
  taskbar: { position: 'absolute', bottom: 0, left: 0, right: 0, height: 54, backgroundColor: 'rgba(12,20,34,0.96)', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 7, gap: 6, borderTopWidth: 1, borderColor: '#52647b', zIndex: 100 },
  startButton: { width: 42, height: 42, borderRadius: 10, backgroundColor: '#253b58', alignItems: 'center', justifyContent: 'center' },
  taskItem: { height: 38, flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 8, borderRadius: 8, backgroundColor: '#26374d' },
  taskActive: { borderBottomWidth: 2, borderBottomColor: '#65aaff' },
  tray: { alignItems: 'flex-end', paddingHorizontal: 5, gap: 2 },
  window: { position: 'absolute', borderWidth: 1, borderRadius: 13, overflow: 'hidden', elevation: 15, shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 12 },
  windowTitle: { height: 43, backgroundColor: '#26364d', flexDirection: 'row', alignItems: 'center', paddingLeft: 13, paddingRight: 6, gap: 4 },
  titleAction: { width: 29, height: 29, backgroundColor: '#3d506a', borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  titleActionText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  closeButton: { width: 31, height: 29, backgroundColor: '#c43d4b', borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.38)', justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 65 },
  startPanel: { width: '94%', maxWidth: 580, height: '72%', borderRadius: 18, padding: 18, elevation: 20 },
  panelHeading: { fontSize: 21, fontWeight: '800', marginBottom: 12 },
  startGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'flex-start', paddingTop: 10 },
  input: { backgroundColor: '#26364d', color: '#fff', borderRadius: 9, paddingHorizontal: 12, paddingVertical: 10, borderWidth: 1, borderColor: '#52647b' },
  muted: { color: '#9eacc0', fontSize: 12 },
  sectionTitle: { fontSize: 18, fontWeight: '800' },
  addressRow: { flexDirection: 'row', gap: 7, marginBottom: 4 },
  primaryButton: { backgroundColor: '#2563eb', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 8, justifyContent: 'center' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 12 },
  browserControls: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  browserButton: { width: 32, height: 30, backgroundColor: '#31445e', borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  webFrame: { flex: 1, borderRadius: 9, overflow: 'hidden' },
  fileToolbar: { flexDirection: 'row', marginBottom: 6 },
  fileRow: { flexDirection: 'row', alignItems: 'center', gap: 11, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#52647b' },
  fileName: { flex: 1, fontSize: 14 },
  calcDisplay: { fontSize: 32, textAlign: 'right', padding: 10, fontWeight: '700' },
  calcGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, justifyContent: 'center' },
  calcKey: { width: '22%', height: 39, backgroundColor: '#30435e', borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  settingRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 14, borderBottomWidth: 1, borderColor: '#52647b' },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderColor: '#52647b' },
  storeRow: { flexDirection: 'row', alignItems: 'center', gap: 9, paddingVertical: 11, borderBottomWidth: 1, borderColor: '#52647b' },
  quickPanel: { width: '90%', maxWidth: 440, padding: 18, borderRadius: 16 },
  calendarGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  calendarCell: { width: '14.2857%', minHeight: 34, alignItems: 'center', justifyContent: 'center', borderRadius: 8 },
  todayCell: { backgroundColor: '#2563eb' },
  taskRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderColor: '#52647b' },
  taskCheck: { width: 23, height: 23, borderRadius: 6, borderWidth: 1, borderColor: '#8290a5', alignItems: 'center', justifyContent: 'center' },
  taskChecked: { backgroundColor: '#2563eb', borderColor: '#2563eb' },
  taskTitle: { flex: 1, fontSize: 14 }
};
